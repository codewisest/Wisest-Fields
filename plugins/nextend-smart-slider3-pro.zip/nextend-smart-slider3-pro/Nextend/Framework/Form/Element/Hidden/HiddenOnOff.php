<?php


namespace Nextend\Framework\Form\Element\Hidden;


use Nextend\Framework\Form\Element\OnOff;

class HiddenOnOff extends OnOff {

    protected $rowClass = 'n2_form_element--hidden';

}